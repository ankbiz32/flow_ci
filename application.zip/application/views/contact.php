

    <section class="hero-sec sub-page contact-hero-sec pb-sm-5 pb-0">
        <div class="container">
            <div class="intro">
                <h1 class="mb-5">Contact&nbsp;
                    <span class="flow-mark">
                        <span class="f">f</span>
                        <span class="l">l</span>
                        <span class="o">o</span>
                        <span class="w">w</span>
                    </span> </h1>
                <div class="row mt-5 info-con">
                    <!-- <div class="col-sm-4 text-center info address">
                        <div class="blob-bg"></div>
                        <h3 class=""><i class="fa fa-map-marker-alt"></i></h3>
                        <p class="w-100 mt-3">
                            D-11, Quoram, VIP Square <br>
                            GE Road, Raipur <br>
                            Chhattisgarh (492001)
                        </p>
                    </div>
                    <div class="col-sm-4 info call">
                        <div class="blob-bg"></div>
                        <h3><i class="fa fa-phone"></i></h3>
                        <p class="w-100 mt-3">
                            +91-9766720007 <br>
                            0771-4902000
                        </p>
                    </div>
                    <div class="col-sm-4 info email">
                        <div class="blob-bg"></div>
                        <h3><i class="fa fa-envelope"></i></h3>
                        <p class="w-100 mt-3">
                            info@flowmenow.in
                        </p>
                    </div> -->
                </div>
            </div>
        </div>
        <div class="blobs">
            <div class="blob-pink"></div>
            <div class="blob-baige"></div>
        </div>
    </section>
